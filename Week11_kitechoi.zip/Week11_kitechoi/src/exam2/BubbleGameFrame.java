package exam2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class BubbleGameFrame extends JFrame {

    private JLabel label;
    Thread t;

    class Counter extends Thread{
        public void run() {
            for(int i=0; i<=10; i++) {
                try {
                    Thread.sleep(1000);
                } catch(InterruptedException e) {
                    return;
//                  e.printStackTrace(); 대신 return을 써야 스레드가 중지됨.
                }
                label.setText(i + "");
            }
        }
    }
    public BubbleGameFrame() {
        setTitle("버블 게임");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        GamePanel p = new GamePanel();
        setContentPane(p);
        setSize(500, 500);
        setVisible(true);


    }




    public static void main(String[] args) {
        new BubbleGameFrame();
    }
}

class GamePanel extends JPanel {
    public GamePanel() {
        setLayout(null);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                new BubbleThread(e.getX(), e.getY(), GamePanel.this).start();
            }
        });
    }
}

class BubbleThread extends Thread {
    private JLabel bubble;
    private JPanel parentPanel;

    public BubbleThread(int bubbleX, int bubbleY, JPanel parentPanel) {
        this.parentPanel = parentPanel;

        ImageIcon img = new ImageIcon("bubble.jpg");
        bubble = new JLabel(img);
        bubble.setSize(img.getIconWidth(), img.getIconWidth());
        bubble.setLocation(bubbleX, bubbleY);


        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                parentPanel.add(bubble);
                parentPanel.repaint();
            }
        });
    }

    public void run() {
        while (true) {
            int x = bubble.getX();
            int y = bubble.getY() - 1;

            if (y < 0) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        parentPanel.remove(bubble);
                        parentPanel.repaint();
                    }
                });
                break;
            }

            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    bubble.setLocation(x, y);
                    parentPanel.repaint();
                }
            });

            try {
                sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
